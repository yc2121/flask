from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)

import os, random
app.secret_key=os.urandom(24).encode('hex')

@app.route('/')
def index():
  if 'counter' in session:
    session['counter']+=1
  else:
    session['counter']=1
  return render_template('index.html')

app.run(debug=True)