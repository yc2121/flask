"use strict";
// **** jQuery *****
$(document).ready(function(){
	console.log("document ready for jQuery");
});
