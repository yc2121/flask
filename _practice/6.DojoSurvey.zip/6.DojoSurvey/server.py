from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key='use this secret key'
# Here the index.html is a form with a textbox named 'stringEntered'
@app.route('/')
def index():
  return render_template("index.html")

@app.route('/', methods=['POST'])
def process():
   session['name']    = request.form['nameEntered']
   session['location']= request.form['locationPicked']
   session['language']= request.form['languagePicked']
   session['comment'] = request.form['commentEntered']
   return redirect('/result')

@app.route('/result')
def result():
    return render_template(
      "result.html"
      ,name=session['name']
      ,location=session['location']
      ,language=session['language']
      ,comment=session['comment']
      )

app.run(debug=True)